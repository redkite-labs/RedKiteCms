<?php

namespace Themes\AlphaLemonThemeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AlphaLemonThemeBundle extends Bundle {

}
